#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <random>
#include <set>
#include <map>
#include <sstream>
#include <iomanip>

using namespace std;

// �����������
random_device rd;
mt19937 gen(rd());

// ���������Ȼ��
int generateNaturalNumber(int max) {
    uniform_int_distribution<> dis(1, max - 1);
    return dis(gen);
}

// ������������
string generateFraction(int max) {
    int numerator = generateNaturalNumber(max);
    int denominator = generateNaturalNumber(max);
    if (numerator >= denominator) {
        numerator = denominator - 1;
    }
    return to_string(numerator) + "/" + to_string(denominator);
}

// ������������
char generateOperator() {
    vector<char> operators = { '+', '-', '*', '/' };
    uniform_int_distribution<> dis(0, operators.size() - 1);
    return operators[dis(gen)];
}

// �����������ʽ
string generateExpression(int max, int depth = 0) {
    if (depth >= 3) {
        // ���3�������
        return to_string(generateNaturalNumber(max));
    }

    string expr;
    int choice = generateNaturalNumber(3); // ���ѡ��������Ȼ������������ӱ���ʽ
    if (choice == 1) {
        expr = to_string(generateNaturalNumber(max));
    }
    else if (choice == 2) {
        expr = generateFraction(max);
    }
    else {
        expr = "(" + generateExpression(max, depth + 1) + ")";
    }

    char op = generateOperator();
    string nextExpr = generateExpression(max, depth + 1);

    // ȷ����������������
    if (op == '-' && expr < nextExpr) {
        swap(expr, nextExpr);
    }

    // ȷ���������Ϊ�����
    if (op == '��' && expr >= nextExpr) {
        swap(expr, nextExpr);
    }

    return expr + " " + op + " " + nextExpr;
}

// �������ʽ��ֵ
double calculateExpression(const string& expr) {
    // �������ʹ�ñ���ʽ��������ֶ���������ʽ������
    // ����ʱ���ϵ�������Ϊֱ�ӷ���һ�����ֵ
    uniform_real_distribution<> dis(1.0, 100.0);
    return dis(gen);
}

// ������Ŀ�ʹ�
void generateExercisesAndAnswers(int numExercises, int maxNumber, const string& exerciseFile, const string& answerFile) {
    ofstream exerciseOut(exerciseFile);
    ofstream answerOut(answerFile);

    set<string> uniqueExercises;

    for (int i = 1; i <= numExercises; ++i) {
        string expr;
        do {
            expr = generateExpression(maxNumber);
        } while (uniqueExercises.count(expr));

        uniqueExercises.insert(expr);

        exerciseOut << expr << " =" << endl;
        double answer = calculateExpression(expr);
        answerOut << fixed << setprecision(2) << answer << endl;
    }
}

// �жϴ𰸲�ͳ�ƽ��
void gradeAnswers(const string& exerciseFile, const string& answerFile, const string& gradeFile) {
    ifstream exerciseIn(exerciseFile);
    ifstream answerIn(answerFile);
    ofstream gradeOut(gradeFile);

    vector<int> correct, wrong;
    int index = 1;
    string expr, answer;

    while (getline(exerciseIn, expr) && getline(answerIn, answer)) {
        double calculatedAnswer = calculateExpression(expr);
        double givenAnswer = stod(answer);

        if (abs(calculatedAnswer - givenAnswer) < 1e-6) {
            correct.push_back(index);
        }
        else {
            wrong.push_back(index);
        }
        ++index;
    }

    gradeOut << "Correct: " << correct.size() << " (";
    for (size_t i = 0; i < correct.size(); ++i) {
        gradeOut << correct[i];
        if (i < correct.size() - 1) gradeOut << ", ";
    }
    gradeOut << ")" << endl;

    gradeOut << "Wrong: " << wrong.size() << " (";
    for (size_t i = 0; i < wrong.size(); ++i) {
        gradeOut << wrong[i];
        if (i < wrong.size() - 1) gradeOut << ", ";
    }
    gradeOut << ")" << endl;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cerr << "Usage: " << argv[0] << " -n <number of exercises> -r <range> [-e <exercise file> -a <answer file>]" << endl;
        return 1;
    }

    int numExercises = 0;
    int maxNumber = 0;
    string exerciseFile = "Exercises.txt";
    string answerFile = "Answers.txt";
    string gradeFile = "Grade.txt";

    for (int i = 1; i < argc; ++i) {
        string arg = argv[i];
        if (arg == "-n") {
            numExercises = stoi(argv[++i]);
        }
        else if (arg == "-r") {
            maxNumber = stoi(argv[++i]);
        }
        else if (arg == "-e") {
            exerciseFile = argv[++i];
        }
        else if (arg == "-a") {
            answerFile = argv[++i];
        }
    }

    if (numExercises <= 0 || maxNumber <= 0) {
        cerr << "Invalid arguments. Please specify -n and -r." << endl;
        return 1;
    }

    generateExercisesAndAnswers(numExercises, maxNumber, exerciseFile, answerFile);

    if (argc > 5 && string(argv[5]) == "-e") {
        gradeAnswers(exerciseFile, answerFile, gradeFile);
    }

    return 0;
}